<?php
$sActive = 'properties';
require_once('header.php');
?>

<h1>Properties</h1>

<?php
require_once('footer.php');
?>