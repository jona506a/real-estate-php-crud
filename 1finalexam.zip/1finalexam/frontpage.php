<?php
$sActive = 'frontpage';
require_once('header.php');
?>

<h1>frontpage</h1>

<?php
require_once('footer.php');
?>