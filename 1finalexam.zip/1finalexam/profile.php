<?php
$sActive = 'signup-agent';
require_once('header.php');
?>

<h1>Profile page</h1>



<?php
require_once('footer.php');
?>