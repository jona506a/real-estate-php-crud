<?php
$sActive = 'login';
require_once('header.php');
?>

<h1>Login</h1>

<?php
require_once('footer.php');
?>