<?php
$sActive = 'signup-user';
require_once('header.php');
?>

<h1>Sign up as an user</h1>

<?php
require_once('api-user/api-user-signup.php');
?>


<?php
require_once('footer.php');
?>