<?php


if(empty( $_POST['propertyId'])){
    sendErrorMessage('property id is missing',__LINE__);
    exit;
}

$sPropertyId = $_POST['propertyId'];
if($sPropertyId[0] != 'P'){
    sendErrorMessage('property id should start with a P',__LINE__);
};

if(!$_SESSION){
    sendErrorMessage('You are not logged in',__LINE__);
}
if(empty( $_POST['price'])){
    sendErrorMessage('price is missing',__LINE__);
    exit;
}

if( !ctype_digit( $_POST['price'] ) ){
    sendErrorMessage('price can only be numbers',__LINE__);
    exit;
}

if( $_POST['price'] < 1 ){
    sendErrorMessage('price is too low',__LINE__);
    exit;
}

if( $_POST['price'] > 99999999 ){
    sendErrorMessage('price is too big',__LINE__);
    exit;
}

session_start();
$_SESSION['sAgentId'] = 'A1';

$sPrice = intVal($_POST['price']);

$sAgentId = $_SESSION['sAgentId'];

$sjData = file_get_contents(__DIR__.'/data.json');
$jData = json_decode($sjData);
$jData->agents->$sAgentId->properties->$sPropertyId->price = $_POST['price'];
$sData = json_encode($jData, JSON_PRETTY_PRINT);
file_put_contents(__DIR__.'/data.json', $sData);  ;
echo '{"status":1, "message":"Agent deleted"}';


function sendErrorMessage($sErrorMessage, $iLineNumber){
    echo '{"status":0, "message":"'.$sErrorMessage.'", "line":'.$iLineNumber.'}';
    exit;

}